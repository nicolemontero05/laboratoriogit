package com.mycompany.app02;

import javax.swing.JOptionPane;

/*
SEMANA #02
TEMA: La clase JOptionPane
*/
public class App02Parte2 {

    public static void main(String[] args) {
        // La clase JOptionPane:
        
        // 1- Metodo: showMessageDialog() => Mostrar Informacion.
        JOptionPane.showMessageDialog(null, "Hola, Jonathan");
        
        int num1 = 15;
        int num2 = 100;
        
        JOptionPane.showMessageDialog(null, "La multiplicacion es: " 
                + (num1 * num2)); // jop + ctrl + espacio
        
        // 2- Metodo: showInputDialog() => Ingresar Informacion.
        String nombre = JOptionPane.showInputDialog("Ingrese su nombre:");
        System.out.println("Hola, " + nombre);
        JOptionPane.showMessageDialog(null, "Hola, " + nombre);
        
        // Conversiones:
        
        // Problema #1: Solicitar un numero entero al usuario y se debe
        // mostrar el doble del valor ingresado.
        
        String numeroSTR = JOptionPane
                .showInputDialog("Ingrese un valor numerico:"); // numeroSTR = "30"
        int numero = Integer.parseInt(numeroSTR); // numero = 30
        int doble = numero * 2; // doble = 60
        JOptionPane.showMessageDialog(null, "El doble del numero: " 
                + numeroSTR + " es: " + doble);
        
        // Problema #2: Solicitar el radio en cm de un circulo y mostrar 
        // su area.
        // (area = PI * radio ^ 2)
        
        String radioSTR = JOptionPane
                .showInputDialog("Ingrese el radio del circulo (cm)");
        double radio = Double.parseDouble(radioSTR); // Conversion de String a double
        double area = Math.PI * Math.pow(radio, 2); // Math.sqrt(125) => Raiz Cuadrado.
        JOptionPane.showMessageDialog(null, "La area del circulo es: " 
                + area + "cm");
        
        
        
        
    }
    
}
