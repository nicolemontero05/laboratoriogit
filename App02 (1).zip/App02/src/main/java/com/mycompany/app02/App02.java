package com.mycompany.app02;

/*
SEMANA #02
TEMA: Variables
 */
public class App02 {

    public static void main(String[] args) {

        // Variables:
        // Declaracion e Inicializacion de una variable:
        String nombre = "Alex";
        String apellido = "Campos";
        int edad = 32;
        double salario = 1799.99;

        // Mostrar los valores (print y println)
        System.out.print("Datos del empleado:");
        System.out.print("\n"); // alt + 92
        System.out.print(nombre);

        System.out.println();
        System.out.println("Salario:");
        System.out.println(salario); // sout + tab

        // Concatenar:
        String saludo = "Bienvenido " + nombre + " " + apellido
                + " y su edad es: " + edad + " años";

        System.out.println(saludo);

        System.out.println("Su nombre completo es " + nombre + " " + apellido
                + ", su salario es: $" + salario);
        
        // Operaciones Aritmeticas:
        
        double nuevoSalario = salario + 300;
        System.out.println("Su nuevo salario es: $" + nuevoSalario);
        
        System.out.println("Nueva edad: " + (edad - 5) + " años");
        
        // Multiplicar: *
        // Dividir: /
        // Modulacion: %

    }
}
