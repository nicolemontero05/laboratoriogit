package com.mycompany.app02;

/*
SEMANA #02
TEMA: La clase String
*/
public class App02Parte3 {

    public static void main(String[] args) {
        // La clase String
        
        // Referencia (Objetos):
        String descripcion = "Es una casa vieja y sin pintura "
                + "arriba en las montañas";
        
        // Primitivos:
        int numero = 4;
        double precio = 85.5;
        boolean estado = false;
        char letra = 'J';
                
        // Metodos de la clase String:
        
        // Metodo: length()
        int cantidadCaracteres = descripcion.length();
        System.out.println("La cantidade de caracteres es: " 
                + cantidadCaracteres);
        
        
    }
    
}
