package com.mycompany.app03;

import javax.swing.JOptionPane;

/*
SEMANA #03
TEMA: Condicionales
 */
public class App03Parte2 {

    public static void main(String[] args) {
        // Condicion simple (if)

//        String edadSTR = JOptionPane.showInputDialog("Ingrese su edad");
//        int edad = Integer.parseInt(edadSTR);
//        
//        if (edad >= 18) {
//            JOptionPane.showMessageDialog(null, 
//                    "Puede ingresar al laboratorio.");
//        } 
        // No se puede usar condicionales sin llaves en Java.
        // Codicion doble (if/else)
//        int edad = Integer.parseInt(JOptionPane
//                .showInputDialog("Ingrese su edad:"));
//        
//        if (edad >= 21) {
//            JOptionPane.showMessageDialog(null,
//                    "Puede ingresar al laboratorio.");
//        } else {
//            JOptionPane.showMessageDialog(null,
//                    "No puede ingresar al laboratorio.");
//        }
        // Condicion doble (if/else)
//        int edad = Integer.parseInt(JOptionPane
//                .showInputDialog("Ingrese su edad:"));
//        
//        // 3- Metodo: showConfirmDialog(): Ingreso informacion por botones.
//        // Si = 0
//        // No = 1
//        // Cancelar = 2
//        // X = -1
//        int respuesta = JOptionPane.showConfirmDialog(null, 
//                "¿Tiene autorizacion para ingresar al laboratorio?");
//        boolean autorizado = false;
//        
//        if (respuesta == 0) {
//            autorizado = true;
//        }
//        
//        // && => and
//        // || => or
//        // ! => not
//        
//        if (edad >= 21 && autorizado) {
//            JOptionPane.showMessageDialog(null,
//                    "Puede ingresar al laboratorio.");
//        } else {
//            JOptionPane.showMessageDialog(null,
//                    "No puede ingresar al laboratorio.");
//        }
        // Condicional anidado (if/else)
//        int edad = Integer.parseInt(JOptionPane
//                .showInputDialog("Ingrese su edad:"));
//
//        if (edad >= 18) {
//
//            int horas = Integer.parseInt(JOptionPane.showInputDialog(
//                    "Ingrese la cantidad de horas:"));
//
//            // ifelse + tab
//            
//            if (horas <= 4) {
//                JOptionPane.showMessageDialog(null, "Puede ingresar al laboratorio "
//                        + "por " + horas + " horas.");
//            } else {
//                JOptionPane.showMessageDialog(null, "Puede ingresar al laboratorio "
//                        + "pero solo por un maximo de 4 horas");
//            }
//
//        } else {
//            JOptionPane.showMessageDialog(null,
//                    "No puede ingresar al laboratorio por ser menor de edad.");
//        }
        // Condicion multiple (if / else if)
        int nota = Integer.parseInt(JOptionPane.showInputDialog(
                "Ingrese la nota final:"));

        if (nota >= 70 && nota <= 100) {
            JOptionPane.showMessageDialog(null, "Estado: Aprobado.");
        } else if (nota >= 60 && nota < 70) {
            JOptionPane.showMessageDialog(null, "Estado: Aplazado.");
        } else if (nota >= 0 && nota < 60) {
            JOptionPane.showMessageDialog(null, "Estado: Reprobado.");
        } else {
            JOptionPane.showMessageDialog(null, "La nota no es valida.");
        }

        // Condicion multiple (switch)
        // Alt + 92 = \
        int opcion = Integer.parseInt(JOptionPane.showInputDialog(
                "Seleccione el turno del laboratorio:\n"
                + "1- Mañana\n"
                + "2- Tarde\n"
                + "3- Noche"));

        switch (opcion) {
            case 1:
                JOptionPane.showMessageDialog(null, "Costo del turno mañana: ¢3000");
                break;
            case 2:
                JOptionPane.showMessageDialog(null, "Costo del turno tarde: ¢2500");
                break;
            case 3:
                JOptionPane.showMessageDialog(null, "Costo del turno noche: ¢2000");
                break;  
            default:
                JOptionPane.showMessageDialog(null, "Opcion no valida.");
                break;
        }

    }

}
