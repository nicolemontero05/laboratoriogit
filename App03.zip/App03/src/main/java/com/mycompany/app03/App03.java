package com.mycompany.app03;

/*
SEMANA #03
TEMA: La Clase String
*/
public class App03 {

    public static void main(String[] args) {
        // Metodos de la clase String:
        
        String texto = "Es una casa vieja y sin pintura arriba"
                + " en las montañas.";
        String nombre = "Daniel";
        
        // Metodo: length()
        int cantidadCaracteres = texto.length();
        System.out.println("La cantidad es: " + cantidadCaracteres);
        
        // Metodo: charAt()
        char caracter = nombre.charAt(0);
        System.out.println("El caracter es: " + caracter);
        
        caracter = texto.charAt(7);
        System.out.println("El caracter es: " + caracter);
        
        // Metodo: indexOf()
        int indice = texto.indexOf('v');
        System.out.println("La posicion es: " + indice);
        
        indice = texto.indexOf('p');
        System.out.println("La posicion es: " + indice);
        
        indice = texto.indexOf('a');
        System.out.println("La posicion es: " + indice);
        
        indice = texto.indexOf('a', 6);
        System.out.println("La posicion es: " + indice);
        
        // Metodo: substring()
        String subtexto = texto.substring(32);
        System.out.println("El subtexto es: " + subtexto);
        
        subtexto = texto.substring(20, 31); 
        System.out.println("El subtexto es: " + subtexto);

        // "Es una casa vieja y sin pintura arriba en las montañas."
        
    }
}
